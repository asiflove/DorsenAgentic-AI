const agents = [
  ['Research Agent', 'Explore topics, organize findings and create clear summaries.'],
  ['Business Agent', 'Structure ideas, plans and responsible business workflows.'],
  ['Marketing Agent', 'Draft campaigns, content calendars and brand messages.'],
  ['Coding Agent', 'Plan software features and help explain code.'],
  ['Learning Agent', 'Create learning paths, lessons and practice activities.'],
  ['Team Agent', 'Organize projects, roles, tasks and team updates.'],
  ['Automation Agent', 'Design workflows with approval before external actions.']
];
const modules = [
  ['AI Agent Studio', 'A workspace for specialized AI assistants.'],
  ['Website & App Builder', 'Plan and prototype digital products.'],
  ['Education Academy', 'Learning resources and motivation tools.'],
  ['Team & Community', 'Projects, tasks and community coordination.'],
  ['Business & Marketing', 'Content planning and business resources.'],
  ['Automation Marketplace', 'A future home for reusable workflows and integrations.']
];
export default function Home() {
  return <main>
    <nav className="nav"><a className="brand" href="#top"><span className="brand-mark">D</span>Dorsen<span>Agentic AI</span></a><div className="navlinks"><a href="#agents">AI Agents</a><a href="#modules">Platform</a><a href="#roadmap">Roadmap</a></div><a className="nav-cta" href="#start">Explore platform ↗</a></nav>
    <section className="hero" id="top"><div className="eyebrow"><i/> THE ALL-IN-ONE AI WORK PLATFORM</div><h1>Turn ideas into<br/><em>intelligent action.</em></h1><p className="hero-copy">One workspace for AI agents, learning, teams and digital product creation. Build thoughtfully, work smarter and grow together.</p><div className="hero-actions"><a className="primary" href="#agents">Explore AI agents <b>→</b></a><a className="secondary" href="#roadmap">See what’s coming</a></div><div className="hero-note">A new platform by <strong>DorsenLabs</strong></div><div className="orb orb-one"/><div className="orb orb-two"/></section>
    <section className="stats"><div><strong>01</strong><span>Unified workspace</span></div><div><strong>07</strong><span>Agent concepts</span></div><div><strong>06</strong><span>Platform modules</span></div><div><strong>∞</strong><span>Room to extend</span></div></section>
    <section className="section" id="agents"><div className="section-head"><div><div className="eyebrow">SPECIALIZED INTELLIGENCE</div><h2>Meet your AI team.</h2></div><p>Purpose-built agent experiences designed to help people think, create, learn and organize work.</p></div><div className="cards">{agents.map(([name,desc],i)=><article className="agent-card" key={name}><div className="card-top"><span className="agent-icon">{['⌕','◈','✳','⌘','▤','♧','⤳'][i]}</span><span className="number">0{i+1}</span></div><h3>{name}</h3><p>{desc}</p><span className="soon">PLANNED MODULE</span></article>)}</div></section>
    <section className="section modules" id="modules"><div className="eyebrow">ONE CONNECTED ECOSYSTEM</div><h2>More than a chatbot.</h2><p className="section-intro">A modular platform designed to expand as new tools, agents and integrations are added.</p><div className="module-grid">{modules.map(([name,desc],i)=><article className="module" key={name}><span className="module-num">0{i+1} / MODULE</span><h3>{name}</h3><p>{desc}</p><span className="arrow">↗</span></article>)}</div></section>
    <section className="roadmap" id="roadmap"><div className="eyebrow">BUILT IN PHASES</div><h2>Start focused.<br/><em>Expand without limits.</em></h2><div className="phases"><div><b>01</b><strong>Foundation</strong><p>Responsive platform shell and deployment.</p></div><div><b>02</b><strong>Accounts & data</strong><p>Authentication, profiles and saved work.</p></div><div><b>03</b><strong>AI connections</strong><p>Connect model providers with usage controls.</p></div><div><b>04</b><strong>Agent workflows</strong><p>Tools, permissions and approval steps.</p></div></div></section>
    <section className="start" id="start"><div className="eyebrow">THE JOURNEY STARTS HERE</div><h2>Build a smarter way<br/>to get work done.</h2><p>DorsenAgentic AI is being developed in stages. This first release is a visual foundation, not a live AI service.</p><a className="primary" href="mailto:hello@dorsen.org">Contact DorsenLabs <b>→</b></a></section>
    <footer><a className="brand" href="#top"><span className="brand-mark">D</span>Dorsen<span>Agentic AI</span></a><span>© 2026 DorsenLabs. Platform foundation preview.</span><a href="#top">Back to top ↑</a></footer>
  </main>;
}
