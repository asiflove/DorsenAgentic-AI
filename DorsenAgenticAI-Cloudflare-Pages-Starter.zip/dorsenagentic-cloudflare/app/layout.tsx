import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'DorsenAgentic AI — Your AI Work Platform',
  description: 'An all-in-one workspace for AI agents, learning, teams and building digital products.',
  manifest: '/manifest.webmanifest',
  applicationName: 'DorsenAgentic AI'
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
